function checkAnswer1(option1){
    let answer1 =option1.textContent;
    let result1 = document.getElementById('result1');

    if (answer1 === 'Berto'){
        result1.textContent ='Correct Answer!';
        result1.style.color ='green';
        option1.classList.add('correct');
    }
    else{
        result1.textContent ='Wrong Answer!';
        result1.style.color ='red';
        option1.classList.add('incorrect');
        1
    }
    document.querySelectorAll('.option1').forEach(item => {
    if (item.textContent!== answer){
        item.classList.add('incorrect');
    }
    item.ariaDisabled ='true';
    })

    
}

function checkAnswer2(option2){
    let answer =option2.textContent;
    let result2 = document.getElementById('result2');

    if (answer === 'Musiko'){
        result2.textContent ='Correct Answer!';
        result2.style.color ='green';
        option2.classList.add('correct');
    }
    else{
        result2.textContent ='Wrong Answer!';
        result2.style.color ='red';
        option2.classList.add('incorrect');
        
    }
    document.querySelectorAll('.option2').forEach(item => {
    if (item.textContent!== answer){
        item.classList.add('incorrect');
    }
    item.ariaDisabled ='true';
    })

    
}
function checkAnswer3(option3){
    let answer =option3.textContent;
    let result3 = document.getElementById('result3');

    if (answer === 'Luna'){
        result3.textContent ='Correct Answer!';
        result3.style.color ='green';
        option3.classList.add('correct');
    }
    else{
        result3.textContent ='Wrong Answer!';
        result3.style.color ='red';
        option3.classList.add('incorrect');
        
    }
    document.querySelectorAll('.option3').forEach(item => {
    if (item3.textContent!== answer){
        item3.classList.add('incorrect');
    }
    item.ariaDisabled ='true';
    })

    
}

function check4(option4){
    
    let answer =option4.textContent;
    let result4 = document.getElementById('result4');

    if (answer === 'Aljhon'){
        result4.textContent ='Correct Answer!';
        result4.style.color ='green';
        option4.classList.add('correct');
    }
    else{
        result4.textContent ='Wrong Answer!';
        result4.style.color ='red';
        option4.classList.add('incorrect');
        
    }
    document.querySelectorAll('.option4').forEach(item => {
    if (item4.textContent!== answer){
        item4.classList.add('incorrect');
    }
    item.ariaDisabled ='true';
    })

    
}

function check5(option5){
    let answer =option5.textContent;
    let result5 = document.getElementById('result5');

    if (answer === 'Butig'){
        result5.textContent ='Correct Answer!';
        result5.style.color ='green';
        option5.classList.add('correct');
    }
    else{
        result5.textContent ='Wrong Answer!';
        result5.style.color ='red';
        option5.classList.add('incorrect');
        
    }
    document.querySelectorAll('.option4').forEach(item => {
    if (item5.textContent!== answer){
        item5.classList.add('incorrect');
    }
    item.ariaDisabled ='true';
    })

    
}

function check6(option6){
    let answer =option6.textContent;
    let result6 = document.getElementById('result6');

    if (answer === 'Aya'){
        result6.textContent ='Correct Answer!';
        result6.style.color ='green';
        option6.classList.add('correct');
    }
    else{
        result6.textContent ='Wrong Answer!';
        result6.style.color ='red';
        option6.classList.add('incorrect');
        
    }
    document.querySelectorAll('.option6').forEach(item => {
    if (item6.textContent!== answer){
        item6.classList.add('incorrect');
    }
    item.ariaDisabled ='true';
    })

    
}

function check7(option7){
    let answer =option7.textContent;
    let result7 = document.getElementById('result7');

    if (answer === 'Musiko'){
        result7.textContent ='Correct Answer!';
        result7.style.color ='green';
        option7.classList.add('correct');
    }
    else{
        result7.textContent ='Wrong Answer!';
        result7.style.color ='red';
        option7.classList.add('incorrect');
        
    }
    document.querySelectorAll('.option7').forEach(item => {
    if (item7.textContent!== answer){
        item7.classList.add('incorrect');
    }
    item.ariaDisabled ='true';
    })

    
}

function check8(option8){
    let answer =option8.textContent;
    let result8 = document.getElementById('result8');

    if (answer === 'Aya'){
        result8.textContent ='Correct Answer!';
        result8.style.color ='green';
        option8.classList.add('correct');
    }
    else{
        result8.textContent ='Wrong Answer!';
        result8.style.color ='red';
        option8.classList.add('incorrect');
        
    }
    document.querySelectorAll('.option8').forEach(item => {
    if (item.textContent!== answer){
        item.classList.add('incorrect');
    }
    item.ariaDisabled ='true';
    })

    
}

function check9(option9){
    let answer =option9.textContent;
    let result9 = document.getElementById('result9');

    if (answer === 'Luna'){
        result9.textContent ='Correct Answer!';
        result9.style.color ='green';
        option9.classList.add('correct');
    }
    else{
        result9.textContent ='Wrong Answer!';
        result9.style.color ='red';
        option9.classList.add('incorrect');
        
    }
    document.querySelectorAll('.option9').forEach(item => {
    if (item.textContent!== answer){
        item.classList.add('incorrect');
    }
    item.ariaDisabled ='true';
    })

    
}

function check10(option10){
    let answer =option10.textContent;
    let result10 = document.getElementById('result10');

    if (answer === 'Abante'){
        result10.textContent ='Correct Answer!';
        result10.style.color ='green';
        option10.classList.add('correct');
    }
    else{
        result10.textContent ='Wrong Answer!';
        result10.style.color ='red';
        option10.classList.add('incorrect');
        
    }
    document.querySelectorAll('.option10').forEach(item => {
    if (item.textContent!== answer){
        item.classList.add('incorrect');
    }
    item.ariaDisabled ='true';
    })

    
}
   
